export const pizza_app =  `
`;